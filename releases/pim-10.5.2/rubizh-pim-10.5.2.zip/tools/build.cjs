const fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..'),file=path.join(root,'rubizh_pim.html');let html=fs.readFileSync(file,'utf8');
for(const [name,start,end] of [
 ['kits-ui.inc.js','// Included in the application before startup.','function typedCategoryDecision'],
 ['content.inc.js','function ceSupplierRewrite(', 'const tzOldCheck=vCheck;'],
 ['sync.inc.js','async function rememberSiteCredentials105(', 'async function sbBeforeLoad()'],
 ['performance.inc.js','// Fact extraction is repeated during preview,', '// Keep the historical identity fingerprint'],
 ['storage.inc.js','// Keep the historical identity fingerprint', '/* ===================== старт ===================== */']
]){
 const a=html.indexOf(start),b=html.indexOf(end,a);
 if(a<0||b<a||html.indexOf(start,a+1)>=0)throw Error('Missing or duplicate source marker: '+name);
 const source=fs.readFileSync(path.join(root,'lib',name),'utf8')+(name==='content.inc.js'?'\n'+fs.readFileSync(path.join(root,'lib/localization.inc.js'),'utf8'):'');
 html=html.slice(0,a)+source+'\n'+html.slice(b);
}
fs.writeFileSync(file,html);console.log('Application sources assembled.');
